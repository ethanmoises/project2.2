const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bcrypt = require('bcrypt');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/uploads/') // Make sure this directory exists
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});

const upload = multer({ storage: storage });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('public/uploads')); // Serve uploaded files

// MongoDB connection
const uri = "mongodb+srv://ethanjames09090909:H6NqeQcwzWFHG3Rf@skillswipe.skf8f.mongodb.net/?retryWrites=true&w=majority&appName=skillswipe";
const client = new MongoClient(uri);

// Serve the HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Registration endpoint
app.post('/register', async (req, res) => {
    try {
        await client.connect();
        const db = client.db('skillswipe');
        const users = db.collection('users');

        const { fullName, email, password } = req.body;

        // Check if user already exists
        const existingUser = await users.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const newUser = {
            fullName,
            email,
            password: hashedPassword,
            profileCompleted: false
        };

        const result = await users.insertOne(newUser);
        res.status(201).json({ 
            message: 'User registered successfully', 
            userId: result.insertedId 
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error registering user' });
    }
});

// Add the complete-profile endpoint
app.post('/complete-profile', upload.single('picture'), async (req, res) => {
    try {
        await client.connect();
        const db = client.db('skillswipe');
        const users = db.collection('users');

        const { userId, about, skillsToShare, skillsToLearn } = req.body;
        
        // Create the picture URL
        const pictureUrl = req.file ? `/uploads/${req.file.filename}` : null;

        const result = await users.updateOne(
            { _id: new ObjectId(userId) },
            {
                $set: {
                    picture: pictureUrl,
                    about,
                    skillsToShare: skillsToShare.split(',').map(skill => skill.trim()),
                    skillsToLearn: skillsToLearn.split(',').map(skill => skill.trim()),
                    profileCompleted: true
                }
            }
        );

        if (result.modifiedCount === 1) {
            res.status(200).json({ 
                message: 'Profile completed successfully',
                pictureUrl: pictureUrl
            });
        } else {
            res.status(400).json({ message: 'Failed to update profile' });
        }
    } catch (error) {
        console.error('Error completing profile:', error);
        res.status(500).json({ message: 'Error completing profile' });
    } finally {
        await client.close();
    }
});

// Add this login endpoint to your existing app.js
app.post('/login', async (req, res) => {
    try {
        await client.connect();
        const db = client.db('skillswipe');
        const users = db.collection('users');

        const { email, password } = req.body;

        // Find user by email
        const user = await users.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        // Compare password
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        // Send user data (excluding password)
        const { password: _, ...userData } = user;
        res.status(200).json({ 
            message: 'Login successful',
            user: userData
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Error during login' });
    } finally {
        await client.close();
    }
});

// Update the /api/users/next endpoint to fetch all available users
app.get('/api/users/next', async (req, res) => {
    try {
        await client.connect();
        const db = client.db('skillswipe');
        const users = db.collection('users');

        // Get the current user's ID from query parameter
        const currentUserId = req.query.currentUserId;

        // Find all users except the current user
        const allUsers = await users.find(
            { 
                profileCompleted: true,
                _id: { $ne: new ObjectId(currentUserId) }
            },
            { 
                projection: { 
                    password: 0
                } 
            }
        ).toArray();

        if (allUsers.length === 0) {
            return res.status(404).json({ message: 'No users available' });
        }

        res.json(allUsers);
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ message: 'Error fetching user data' });
    } finally {
        await client.close();
    }
});

app.get('/api/users/matches/:userId', async (req, res) => {
    try {
        await client.connect();
        const db = client.db('skillswipe');
        const matches = db.collection('matches');
        const users = db.collection('users');

        const userId = new ObjectId(req.params.userId);

        // Find all matches for the user
        const userMatches = await matches.find({
            users: userId
        }).toArray();

        // Get the matched user IDs (excluding the current user)
        const matchedUserIds = userMatches.map(match => 
            match.users.find(id => !id.equals(userId))
        ).filter(id => id); // Filter out any undefined values

        // Fetch the matched users' details
        const matchedUsers = await users.find(
            { _id: { $in: matchedUserIds } },
            { projection: { password: 0 } }
        ).toArray();

        res.json(matchedUsers);
    } catch (error) {
        console.error('Error fetching matches:', error);
        res.status(500).json({ message: 'Error fetching matches' });
    }
});

// Update the likes endpoint to properly handle matches
app.post('/api/likes', async (req, res) => {
    try {
        await client.connect();
        const db = client.db('skillswipe');
        const likes = db.collection('likes');
        const matches = db.collection('matches');

        const { userId, likedUserId } = req.body;

        // Store the like
        await likes.insertOne({
            userId: new ObjectId(userId),
            likedUserId: new ObjectId(likedUserId),
            createdAt: new Date()
        });

        // Check if there's a mutual like
        const mutualLike = await likes.findOne({
            userId: new ObjectId(likedUserId),
            likedUserId: new ObjectId(userId)
        });

        if (mutualLike) {
            // Create a match if it doesn't exist
            const existingMatch = await matches.findOne({
                users: { 
                    $all: [new ObjectId(userId), new ObjectId(likedUserId)]
                }
            });

            if (!existingMatch) {
                await matches.insertOne({
                    users: [new ObjectId(userId), new ObjectId(likedUserId)],
                    createdAt: new Date()
                });
            }
            res.json({ matched: true });
        } else {
            res.json({ matched: false });
        }

    } catch (error) {
        console.error('Error processing like:', error);
        res.status(500).json({ message: 'Error processing like' });
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
